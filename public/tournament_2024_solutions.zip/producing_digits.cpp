#include <bits/stdc++.h>
 
using namespace std;
 
//solve test case
string solveTC(){
    int N;
    string ans = "";
    cin >> N;
    vector<int> a, b;
    int ai;
    for(int i = 0; i < N; i++){
        cin >> ai;
        a.push_back(abs(ai) % 10);
    }
    for(int i = 0; i < N; i++){
        cin >> ai;
        b.push_back(ai);
    }
    bool dp[10];
    for(int i = 0; i < 10; i++) dp[i] = false;
    vector<int> newDP;
    bool added = false;
    for(int i = 0; i < N; i++){
        if(a[i] == b[i]) {
            ans += "Y";
            added = true;
        }
        newDP.push_back(a[i]);
        for(int j = 0; j < 10; j++){
            if(dp[j]){
                newDP.push_back((j * a[i]) % 10);
                if(!added && (j * a[i]) % 10 == b[i]){
                    ans += "Y";
                    added = true;
                }
            }
            
        }
        if(!added) ans += "N";
        for(int j : newDP) dp[j] = true;
        newDP.clear(); added = false;
    }
 
    return ans;
}
 
int main(){
    int T;
    cin >> T;
    while(T--){
        cout << solveTC() << endl;
    } 
}
