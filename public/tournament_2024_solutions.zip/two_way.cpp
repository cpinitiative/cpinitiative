#include <bits/stdc++.h>
using namespace std;
 
int n, a, b;
long long va[100002], vb[100002], dp[2][40], sol;
 
int main ()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    for(int i = 0; i <= 1; i++)
        for(int j = 0; j <= 32; j++)
            dp[i][j] = (1LL<<62);
            
    cin >> n;
    
    for(int i = 0; i < n; i++)
        cin >> va[i];
    for(int i = 0; i < n; i++)
        cin >> vb[i];
 
    dp[0][1] = va[0];
    dp[0][0] = vb[0];
    for(int i = 1; i < n; i++)
    {
        a = va[i];
        b = vb[i];
        
        dp[1][0] = dp[0][0] + b;
        
        for(int j = 1; j <= 32; j++)
            dp[1][j] = min(dp[0][j-1] + (1LL << (j-1)) * a, dp[0][j] + (1LL << j) * b);
 
        for(int j = 0; j <= 32; j++)
            dp[0][j] = dp[1][j];
    }
 
    sol = (1LL << 62);
    for(int j = 0; j <= 32; j++)
        sol = min(sol, dp[0][j]);
    cout << sol;
    return 0;
}

