#include <bits/stdc++.h>
using namespace std;
 
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	
	int t;
	cin >> t;
	
	for(; t; t--)
	{
		int W, D, L, Gf, Ga;
		cin >> W >> D >> L >> Gf >> Ga;
		
		if(W < L)
		{
			swap(Gf, Ga);
			swap(W, L);
		}
		
		// 0 games 
		if(W + D + L == 0)
		{
			if(Gf + Ga == 0)
			{
				cout << "Amazing\n";
				continue;
			}
			else
			{
				cout << "Better luck next time\n";
				continue;
			}
		}
		
		// 1 game
		if(W + D + L == 1)
		{
			if(W == 1 && Gf > Ga)
			{
				cout << "Amazing\n";
				continue;
			}
			if(D == 1 && Gf == Ga)
			{
				cout << "Amazing\n";
				continue;
			}
            if(L == 1 && Gf < Ga)
            {
                cout << "Amazing\n";
                continue;
            }
            cout << "Better luck next time\n";
            continue;
		}
        
        if(L == 0)
        {
            if(Gf - Ga < W)
            {
                cout << "Better luck next time\n";
                continue;
            }
        }
		// we'll start from 1-0 wins, 0-0 draws and 0-1 defeats
		
		Gf -= W;
		Ga -= L;
		
		if(Gf >= 0 && Ga >= 0)
		{
			if(Ga == 0)
			{
				if(W == 1 || (W && Gf <= 1))
				{
					cout << "Amazing\n";
					continue;
				}
			}
			if(Gf == 0)
			{
				if(L == 1 || (L && Ga <= 1))
				{
					cout << "Amazing\n";
					continue;
				}
			}
			int cnt_results = (W > 0) + (D > 0) + (L > 0);
			if(cnt_results == 1 && (Gf == 1 && Ga == 1))
			{
				cout << "Amazing\n";
				continue;
			}
			if(W + L == 0)
			{
				if(Gf == Ga && Gf <= 1)
				{
					cout << "Amazing\n";
					continue;
				}
				if(Gf == Ga && D == 1)
				{
					cout << "Amazing\n";
					continue;
				}
			}
		}
 
		cout << "Better luck next time\n";
		continue;
	}
}
