#include <bits/stdc++.h>
#define int long long
#define mod 1000000007
using namespace std;
 
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    #ifdef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    freopen("error.txt","w",stderr);
    #endif
    int n;
    cin>>n;
    vector<int> v(n);
    for(int &a:v ) cin>>a;
    map<int,int> m;
    int i=0,j=0;
    int ans=1;
    while(j<n){
        m[v[j]]++;
        while(m.size()>3){
            m[v[i]]--;
            if(m[v[i]]==0)
            { m.erase(v[i]);}
            i++;
        }
        ans=max(ans,j-i+1);
        j++;
    }
   cout<<ans;
 
 
}

