#include <bits/stdc++.h>
#define pb push_back
#define f first
#define s second
using namespace std;
typedef long long ll;
 
int T, N;
vector<int> vals;
int dp[4][4][16][100007];
 
char has[4][4][16][100007];
int inv[16];
bool hasR[256], hasC[256];
char equiva[2][2];
 
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>T>>N;
    for(int bm = 0; bm < 16; bm++){
        int bm2 = 0;
        for(int i = 0; i < 4; i++){
            if((bm & (1 << i)) != 0){
                bm2 ^= (1 << (3 - i));
            }
        }
        inv[bm] = bm2;
    }
    equiva[0][0] = 'a';
    equiva[0][1] = 'b';
    equiva[1][0] = 'c';
    equiva[1][1] = 'd';
    hasC['a'] = false;
    hasR['a'] = false;
    hasC['b'] = false;
    hasR['b'] = true;
    hasC['c'] = true;
    hasR['c'] = false;
    hasC['d'] = true ;
    hasR['d'] = true;
    while(T > 0){
        T--;
        vals.clear();
        for(int i = 0; i < N; i++){
            int a;
            cin>>a;
            vals.pb(a);
        }
        for(int pos = N - 1; pos >= 0; pos--){
            for(int bm = 1; bm < 16; bm++){
                for(int l = 0; l < 4; l++){
                    for(int r = 0; r < 4; r++){
                        if((bm & (1 << l)) == 0 || (bm & (1 << r)) == 0){
                            continue;
                        }
                        int noCnoR = 1e9;
                        int CnoR = 1e9;
                        int noCR = 1e9;
                        int CR = 1e9;
                        int v = vals[pos];
                        int bmc = inv[bm];
                        //no C no R
                        if(v == r || (bm & (1 << v)) == 0){
                            noCnoR = 1 + dp[l][v][(bm | (1 << v))][pos + 1];
                        }
                        //C no R
                        int rc = 3 - r, lc = 3 - l;
                        if(v == rc || (bmc & (1 << v)) == 0){
                            CnoR = 2 + dp[lc][v][(bmc | (1 << v))][pos + 1];
                        }
                        //no C with R
                        int rr = l, lr = r;
                        if(v == rr || (bm & (1 << v)) == 0){
                            noCR = 2 + dp[lr][v][(bm | (1 << v))][pos + 1];
                        }
                        //both C and R
                        int rcr = 3 - l, lcr = 3 - r;
                        if(v == rcr || (bmc & (1 << v)) == 0){
                            CR = 3 + dp[lcr][v][bmc | (1 << v)][pos + 1];
                        }
                        int sol = 1e9;
                        bool c = false;
                        bool ri = false;
                        if(sol > CnoR){
                            sol = CnoR;
                            c = true, ri = false;
                        }
                        if(sol > CR){
                            sol = CR;
                            c = true, ri = true;
                        }
                        if(sol > noCnoR){
                            sol = noCnoR;
                            c = false, ri = false;
                        }
                        if(sol > noCR){
                            sol = noCR;
                            c = false, ri = true;
                        }
 
                        has[l][r][bm][pos] = equiva[c][ri];
                        dp[l][r][bm][pos] = sol;
                    }
                }
            }
        }
        int l = vals[0], r = vals[0];
        int bm = (1 << vals[0]);
        cout<<"p";
        for(int i = 1; i < N; i++){
            char ha = has[l][r][bm][i];
            bool ri = hasR[ha];
            bool c = hasC[ha];
            if(c){
                cout<<"c";
                bm = inv[bm];
                l = 3 - l;
                r = 3 - r;
            }
            if(ri){
               cout<<"r";
                swap(l, r);
            }
            bm = (bm | (1 << vals[i]));
            r = vals[i];
            cout<<"p";
        }
        cout<<"\n";
    }
 
    return 0;
}
