#include <bits/stdc++.h>
using namespace std;
 
const int MX = 2e5 + 1;
 
int main() {
    int t; cin >> t;
    vector<int> mu(MX, 1);
    vector<bool> prime(MX, true);
    for(int i = 2; i < MX; i++) {
        if(prime[i]) {
            for(int j = i; j < MX; j += i)
                mu[j] *= -1, prime[j] = false;
        }
    }
    for(int i = 2; i * i < MX; i++) {
        for(int j = i * i; j < MX; j += i * i)
            mu[j] = 0;
    }
    vector<vector<int>> div(MX);
    for(int i = 1; i < MX; i++) {
        for(int j = i; j < MX; j += i) div[j].push_back(i);
    }
    while(t--) {
        int a, b, c; 
        cin >> a >> b >> c;
        long long ans = 0;
        for(int x = 1; a * x + b <= c; x++) {
            int y = (c - a * x) / b;
            for(int i : div[x]) {
                ans += mu[i] * (y / i);
            }
        }
        cout << (ans + 1) % (int)(1e9 + 7) << endl;
    }
}
