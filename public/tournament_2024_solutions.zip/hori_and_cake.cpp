#include <bits/stdc++.h>
using namespace std;
#define int int64_t

const int N = 5000 + 5, mod = 1e9 + 7;
int n, dp[N][N], fac[N], ivf[N], p[N], sz[N];
string str;
vector<int> g[N];

int qp(int a, int b) {
  return b ? qp(a * a % mod, b / 2) * (b & 1 ? a : 1) % mod : 1;
}

int inv(int x) { return qp(x, mod - 2); }

void init() {
  fac[0] = 1;
  for (int i = 1; i < N; i++) {
    fac[i] = fac[i - 1] * i % mod;
  }
  ivf[N - 1] = inv(fac[N - 1]);
  for (int i = N - 2; i >= 0; i--) {
    ivf[i] = ivf[i + 1] * (i + 1) % mod;
  }
}

void dfs(int u) {
  sz[u] = 1;
  if (u != 0) {
    dp[u][0] = 1;
    for (int v : g[u]) {
      dfs(v);
      for (int cur = sz[u]; cur >= 0; cur--) {
        for (int child = sz[v]; child >= 1; child--) {
          if (cur + child <= n) {
            (dp[u][cur + child] += dp[u][cur] * dp[v][child] % mod * ivf[child] % mod) %= mod;
          }
        }
      }
      sz[u] += sz[v];
    }
  } else {
    dp[u][0] = 1;
    for (int v : g[u]) {
      dfs(v);
      vector<int> ndp(n + 1, 0);
      for (int cur = sz[u]; cur >= 0; cur--) {
        for (int child = sz[v]; child >= 1; child--) {
          if (cur + child <= n) {
            (ndp[cur + child] += dp[u][cur] * dp[v][child] % mod * ivf[child] % mod) %= mod;
          }
        }
      }
      sz[u] += sz[v];
      for (int i = 0; i <= sz[u]; i++) {
        dp[u][i] = ndp[i];
      }
    }
  }
  for (int i = 0; i <= n; i++) {
    (dp[u][i] *= fac[i]) %= mod;
  }
  if (p[u] != 0) {
    for (int i = n; i >= 1; i--) {
      (dp[u][i] += dp[u][i - 1]) %= mod;
    }
  } else {
    if (u != 0) {
      for (int i = n; i >= 1; i--) {
        dp[u][i] = dp[u][i - 1];
      }
      dp[u][0] = 0;
    }
  }
}

void solve() {
  cin >> n;
  for (int i = 0; i <= n; i++) {
    for (int j = 0; j <= n; j++) dp[i][j] = 0;
    g[i].clear();
    p[i] = 0;
  }
  stack<int> s; s.push(0); int nxt = 1;
  vector<pair<int, int>> a;
  for (int i = 0; i < n; i++) {
    int l, r; cin >> l >> r;
    a.push_back({l, 1}); a.push_back({r, -1});
  }
  sort(a.begin(), a.end());
  for (int i = 0; i < 2 * n; i++) {
    if (a[i].second == 1) {
      p[nxt] = s.top();
      g[s.top()].push_back(nxt);
      s.push(nxt);
      nxt++;
    } else {
      s.pop();
    }
  }
  dfs(0);
  int ans = 0;
  for (int i = 0; i <= n; i++) {
    (ans += dp[0][i]) %= mod;
  }
  cout << ans << endl;
}

signed main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  init();
  int t;
  cin >> t;
  while (t--)
    solve();
}
