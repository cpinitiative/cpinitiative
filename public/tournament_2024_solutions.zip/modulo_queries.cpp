#include <bits/stdc++.h>
using namespace std;
 
using i64 = long long;
 
const int BLOCK = 500, MAXN = 2e5 + 5, MAXQ = 2e5, MAXA = 2e5 + 5;
 
struct DS {
    int v[MAXN];
    i64 sum[MAXN / BLOCK + 1];
    void upd(int i, int x) {
        sum[i / BLOCK] += x - v[i];
        v[i] = x;
    }
    i64 qsum(int l, int r) {
        i64 s = 0;
        if (l / BLOCK == r / BLOCK) {
            for (int i = l; i <= r; i++) s += v[i];
        } else {
            for (int i = l; i / BLOCK == l / BLOCK; i++) s += v[i];
            for (int i = r; i / BLOCK == r / BLOCK; i--) s += v[i];
            for (int j = l / BLOCK + 1; j < r / BLOCK; j++) s += sum[j];
        }
        return s;
    }
} ds;
 
int N, Q;
int A[MAXN];
i64 pf[MAXN];
vector<int> upd[MAXA], qry[MAXA];
int l[MAXQ], r[MAXQ], x[MAXQ];
i64 ans[MAXQ];
 
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> N >> Q;
    for (int i = 0; i < N; i++) {
        cin >> A[i];
        pf[i + 1] = pf[i] + A[i];
    }
    for (int i = 0; i < N; i++) upd[1].push_back(i);
    for (int h = 0; h < Q; h++) {
        cin >> l[h] >> r[h] >> x[h], l[h]--, r[h]--;
        ans[h] = pf[r[h] + 1] - pf[l[h]];
        qry[x[h]].push_back(h);
    }
    for (int v = 1; v <= MAXA; v++) {
        for (int i : exchange(upd[v], {})) {
            ds.upd(i, A[i] / v);
            if (v <= A[i]) upd[A[i] / (A[i] / v) + 1].push_back(i);
        }
        for (int h : qry[v]) ans[h] -= x[h] * ds.qsum(l[h], r[h]);
    }
    for (int h = 0; h < Q; h++) cout << ans[h] << " \n"[h == Q - 1];
}
