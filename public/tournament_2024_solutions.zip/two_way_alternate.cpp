#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main() {
    ios::sync_with_stdio(0); cin.tie(0);
    int n; cin >> n;
    vector<int> a(n), b(n);
    for (auto& i : a) cin >> i;
    for (auto& i : b) cin >> i;
    int ans = 0;
    for (int i = n - 1; i >= 0; i--) {
        ans = min(2 * ans + a[i], ans + b[i]);
    }
    cout << ans << endl;
}
