length = int(input())
array = list(map(int, input().split()))
 
 
 
 
# get the minimum and maximum number and their index
min_num = array[0]
max_num = array[length - 1]
min_idx = 0
max_idx = length - 1
 
 
for i in range(length):
   if array[i] < min_num:
       min_num = array[i]
       min_idx = i
   if array[i] > max_num:
       max_num = array[i]
       max_idx = i
 
 
 
 
# remove the maximum and minimum number from the array
p = 0
for i in range(length):
   if i != min_idx and i != max_idx:
       array[p] = array[i]
       p += 1
array = array[:-2]
 
 
 
 
# perform two sum to get the two numbers
s = max_num + min_num
prev = set()
answer = -1
for num in array:
   if s - num in prev:
       answer = max(max_num - max(num, s - num), max_num - min(num, s - num))
   prev.add(num)
 
 
 
 
print(answer)
