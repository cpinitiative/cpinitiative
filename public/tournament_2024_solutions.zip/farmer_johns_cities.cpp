#include <bits/stdc++.h>
using namespace std;
 
#define INF 0x42424242
 
typedef vector<pair<int, int>> neighbours;
 
void dijkstra(int N, neighbours g[], int s, int d[])
{
  set<pair<int, int>> Q;
  for (int v=0; v<N; v++)
    d[v] = INF;
  d[s] = 0;
  Q.insert(make_pair(d[s], s));
  while(!Q.empty())
    {
    int u = Q.begin()->second;
    Q.erase(Q.begin());
    for(auto v = g[u].begin(); v != g[u].end(); v++) {
      int dv = d[u] + v->second;
      if (dv < d[v->first])
      {
        if (d[v->first] != INF)
          Q.erase(Q.find(make_pair(d[v->first], v->first)));
        d[v->first] = dv;
        Q.insert(make_pair(d[v->first], v->first));
      }
    }
  }
}
 
int main ()
{
  int N, M, K, s, t;
  cin>>N>>M>>K>>s>>t;
  --s;
  --t;
  neighbours forwards[N], reversed[N];
 
  for(int i=0; i<M; i++)
  {
    int u, v, w;
    cin>>u>>v>>w;
    --u;
    --v;
    forwards[u].push_back(make_pair(v, w));
    reversed[v].push_back(make_pair(u, w));
  }
 
  int ds[N], dt[N];
 
  dijkstra(N, forwards, s, ds);
 
  dijkstra(N, reversed, t, dt);
 
  int ans = ds[t];
 
  for (int i=0; i<K; i++)
  {
    int u, v, w;
    cin>>u>>v>>w;
    --u;
    --v;
    if(ds[u] == INF || dt[v] == INF)
    continue;
    int d = ds[u] + w + dt[v];
    if (d < ans)
    ans = d;
  }
 
  cout<<ans;
 
  return 0;
}
